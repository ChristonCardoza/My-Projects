package com.example.christon.demologinapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by christon on 11-03-2018.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME ="Registration_db";

    /*Table for sinup*/
    public static final String TABLE_NAME ="Sinup_table";
    public static final String COL_1 ="ID";
    public static final String COL_2 ="Name";
    public static final String COL_3 ="User_Name";
    public static final String COL_4 ="Password";

    //Table for patient information
    public static final String TABLE_NAME1 ="Info_table";
    public static final String Info_COL_1 ="FName";
    public static final String Info_COL_2 ="SName";
    public static final String Info_COL_3 ="Id";
    public static final String Info_COL_4 ="Address";
    public static final String Info_COL_5 ="Phonenumber";
    public static final String Info_COL_6 ="Department";
    public static final String Info_COL_7 ="DName";
    public static final String Info_COL_8 ="Diagnosis";
    public static final String Info_COL_9 ="HCondition";
    public static final String Info_COL_10 ="HName";
    public static final String Info_COL_11 ="HAddress";
    public static final String Info_COL_12 ="PPName";
    public static final String Info_COL_13 ="PPNumber";
    public static final String Info_COL_14 ="PPAdress";

    public DatabaseHelper(Context context) {
        super(context,DATABASE_NAME , null, 1);

        //SQLiteDatabase db =this.getWritableDatabase();

    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table "+TABLE_NAME+ "(ID INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL, User_Name TEXT NOT NULL,  Password TEXT NOT NULL)");
        db.execSQL("create table "+TABLE_NAME1+ "( FName TEXT, SName TEXT, Id  INTEGER PRIMARY KEY ,  Address TEXT,  Phonenumber TEXT,  Department TEXT,  DName TEXT,  Diagnosis TEXT,  HCondition TEXT, HName TEXT, HAddress TEXT, PPName TEXT, PPNumber TEXT, PPAdress TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME1);
        onCreate(db);

    }
    public boolean inserData(String name, String username,String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        //contentValues.put(COL_1,id);
        contentValues.put(COL_2,name);
        contentValues.put(COL_3,username);
        contentValues.put(COL_4,password);
        long result =db.insert(TABLE_NAME,null,contentValues);
        if(result == -1)
            return  false;
        else
            return  true;
    }
    public boolean inserIntoData(String fname, String sname,String id,String address,String phonenumber,String department,String dname,String diagnosis,String hcondition,String hname,String haddress,String ppname,String ppnumber,String ppadress){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Info_COL_1,fname);
        contentValues.put(Info_COL_2,sname);
        contentValues.put(Info_COL_3,id);
        contentValues.put(Info_COL_4,address);
        contentValues.put(Info_COL_5,phonenumber);
        contentValues.put(Info_COL_6,department);
        contentValues.put(Info_COL_7,dname);
        contentValues.put(Info_COL_8,diagnosis);
        contentValues.put(Info_COL_9,hcondition);
        contentValues.put(Info_COL_10,hname);
        contentValues.put(Info_COL_11,haddress);
        contentValues.put(Info_COL_12,ppname);
        contentValues.put(Info_COL_13,ppnumber);
        contentValues.put(Info_COL_14,ppadress);

        long result =db.insert(TABLE_NAME1,null,contentValues);
        if(result == -1)
            return  false;
        else
            return  true;
    }

    public Cursor getData(){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select User_Name,Password from "+TABLE_NAME,null);
        return res;

    }

    public Cursor checkid(){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select Id from "+TABLE_NAME1 ,null);
        return res;

    }

//    public Cursor display(){
//
//        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor res = db.rawQuery("select * from "+TABLE_NAME1,null);
//        return res;
//
//    }

    public Cursor getid(String id){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME1 +" where "+Info_COL_3+"=id ",null);
        return res;

    }

}
