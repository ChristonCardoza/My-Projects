package com.example.christon.demologinapp;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    DatabaseHelper myDb;

    EditText PFname,PSname,PId,PAddress,Ph,CDepartmnt,CDname,PDiag,PHCondition,Phname,PhAdress,PPname,PPnumber,PPadress;
    Button Update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        myDb = new DatabaseHelper(this);

        PFname       = (EditText)findViewById(R.id.fname);
        PSname       = (EditText)findViewById(R.id.sname);
        PId          = (EditText)findViewById(R.id.id);
        PAddress     = (EditText)findViewById(R.id.adress);
        Ph           = (EditText)findViewById(R.id.phone);
        CDepartmnt   = (EditText)findViewById(R.id.department);
        CDname       = (EditText)findViewById(R.id.doctor);
        PDiag        = (EditText)findViewById(R.id.diagnosis);
        PHCondition  = (EditText)findViewById(R.id.condition);
        Phname       = (EditText)findViewById(R.id.hospital);
        PhAdress     = (EditText)findViewById(R.id.haddress);
        PPname       = (EditText)findViewById(R.id.PPName);
        PPnumber     = (EditText)findViewById(R.id.PPNumber);
        PPadress     = (EditText)findViewById(R.id.PPAddress);

        Update =(Button)findViewById(R.id.update);


        upDate();

    }



    public void upDate() {
        Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(PFname.getText().toString().equals("") || PId.getText().toString().equals("") || CDepartmnt.getText().toString().equals("") || CDname.getText().toString().equals("")|| PDiag.getText().toString().equals("")|| Phname.getText().toString().equals("")|| PhAdress.getText().toString().equals("")||PPname.getText().toString().equals("")){


                    Toast.makeText(getApplicationContext(),"Please Insert Data",Toast.LENGTH_LONG).show();

                    PFname.setHintTextColor(Color.parseColor("#ffcc0000"));
                    PId.setHintTextColor(Color.parseColor("#ffcc0000"));
                    CDepartmnt.setHintTextColor(Color.parseColor("#ffcc0000"));
                    CDname.setHintTextColor(Color.parseColor("#ffcc0000"));
                    PDiag.setHintTextColor(Color.parseColor("#ffcc0000"));
                    Phname.setHintTextColor(Color.parseColor("#ffcc0000"));
                    PhAdress.setHintTextColor(Color.parseColor("#ffcc0000"));
                    PPname.setHintTextColor(Color.parseColor("#ffcc0000"));



                }
                else{

                    boolean flag =false;
                    Cursor res = myDb.checkid();

                    while (res.moveToNext()) {
                                if (res.getString(0).equals(PId.getText().toString()) || PId.getText().toString().equals("")) {

                                    if(PId.getText().toString().equals("0")){

                                        Toast.makeText(getApplicationContext(),"0 is not valid ",Toast.LENGTH_LONG).show();
                                    }
                                    flag = true;
                                    PId.setHintTextColor(Color.parseColor("#ffcc0000"));


                                }

                    }
                    if(!flag ){
                        boolean isInserted = myDb.inserIntoData(PFname.getText().toString(),PSname.getText().toString(),PId.getText().toString(),PAddress.getText().toString(),Ph.getText().toString(),CDepartmnt.getText().toString(),CDname.getText().toString(),PDiag.getText().toString(),PHCondition.getText().toString(),Phname.getText().toString(),PhAdress.getText().toString(),PPname.getText().toString(),PPnumber.getText().toString(),PPadress.getText().toString());

                        Intent j = new Intent(getApplicationContext(),Main4Activity.class);
                        startActivity(j);
                        Toast.makeText(getApplicationContext(),"Successfully Added The Information ",Toast.LENGTH_LONG).show();
                        finish();

                    }
                    else{
                        Toast.makeText(getApplicationContext(), "This Id Is Already Exist ", Toast.LENGTH_LONG).show();
                        Toast.makeText(getApplicationContext(), "Please Enter Unique Id ", Toast.LENGTH_LONG).show();

                    }

                }





            }
        });
    }


}
