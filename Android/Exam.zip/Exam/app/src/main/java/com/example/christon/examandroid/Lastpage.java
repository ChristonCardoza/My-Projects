package com.example.christon.examandroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Lastpage extends AppCompatActivity {
    TextView txt,txt1,txt2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lastpage);
        txt =(TextView)findViewById(R.id.text);
        txt1 =(TextView)findViewById(R.id.text2);
        txt2 =(TextView)findViewById(R.id.text3);
        String d =getIntent().getStringExtra("department");
        String dt =getIntent().getStringExtra("date");
        String n =getIntent().getStringExtra("name");
        txt.setText(d);
        txt2.setText(dt);
        txt1.setText(n);
    }
}
