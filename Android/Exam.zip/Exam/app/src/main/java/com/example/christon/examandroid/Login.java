package com.example.christon.examandroid;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

import static java.util.Calendar.getInstance;

public class Login extends AppCompatActivity implements AdapterView.OnItemClickListener {
    TextView tv;
    EditText Username, Password,setDate;
    Button Date, login;
    ListView List;
    String[] lisT ={"Medical Software","Big Data","Embedded System","VLSI"};
    private int  mYear,mMonth,mDay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Username =(EditText)findViewById(R.id.name);
        Password =(EditText)findViewById(R.id.password);
        setDate =(EditText)findViewById(R.id.date);
        Date =(Button)findViewById(R.id.setdate);
        login =(Button)findViewById(R.id.login);
        List =(ListView) findViewById(R.id.list);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,lisT);
        List.setAdapter(adapter);
        List.setOnItemClickListener(this);
        log();
        btn();
    }

    private void btn() {
        Date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(Login.this,new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                        setDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                    }
                }, mYear, mMonth, mDay);

                //datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });
    }

    private void log() {
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Username.getText().toString().equals("Christon") &&Password.getText().toString().equals("24747866") ){
                    Intent l = new Intent(Login.this,Lastpage.class);
                    l.putExtra("department",tv.getText());
                    l.putExtra("name",Username.getText().toString());
                    l.putExtra("date",setDate.getText().toString());
                    startActivity(l);

                }
            }
        });
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        tv =(TextView)view;
        Toast.makeText(getApplicationContext(),"you Clicked on "+tv.getText(),Toast.LENGTH_LONG).show();
    }


}
